﻿using Bumbo.Models;

namespace Bumbo.ViewModels
{
    public class FiliaalDistanceViewModel
    {
        public Filialen Filiaal { get; set; }

        public double Distance { get; set; }
    }
}
