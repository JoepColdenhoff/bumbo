﻿using Bumbo.Models;

namespace Bumbo.ViewModels
{
    public class UrenRegistratieWeekOverviewViewModel
    {
        public List<Medewerker> Medewerker { get; set; }
    }
}
