﻿using Bumbo.Models;

namespace Bumbo.ViewModels
{
    public class MedewerkerDiensten
    {
        public List<DienstViewModel> Diensten { get; set; }

    }
}
