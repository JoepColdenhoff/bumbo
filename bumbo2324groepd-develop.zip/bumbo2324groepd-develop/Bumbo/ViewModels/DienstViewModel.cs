﻿using Bumbo.Models;

namespace Bumbo.ViewModels
{
    public class DienstViewModel
    {
        public Diensten Dienst { get; set; }
        public string FunctieNaam { get; set; }
    }
}
