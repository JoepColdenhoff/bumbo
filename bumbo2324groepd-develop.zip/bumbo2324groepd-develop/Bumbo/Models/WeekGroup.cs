﻿namespace Bumbo.Models;

public class WeekGroup
{
    public int WeekNumber { get; set; }

    public int Amount { get; set; }

    public bool isComplete { get; set; }

    public string Status { get; set; }
}
