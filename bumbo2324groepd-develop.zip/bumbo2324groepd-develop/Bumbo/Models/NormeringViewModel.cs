﻿namespace Bumbo.Models
{
    public class NormeringViewModel
    {
    }
}
