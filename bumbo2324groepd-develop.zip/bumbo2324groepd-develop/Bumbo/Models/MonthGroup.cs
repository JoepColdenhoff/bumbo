﻿namespace Bumbo.Models
{
    public class MonthGroup
    {
        public int Month { get; set; }

        public bool isComplete { get; set; }
    }
}