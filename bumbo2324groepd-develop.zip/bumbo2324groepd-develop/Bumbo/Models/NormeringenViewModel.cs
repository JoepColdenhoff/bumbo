﻿namespace Bumbo.Models;

public class NormeringenViewModel
{
    public List<Normeringen> NormeringenList { get; set; }
}
