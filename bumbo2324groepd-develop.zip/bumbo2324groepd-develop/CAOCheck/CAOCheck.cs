﻿using Bumbo.Models;
namespace CAOCheck
{
    public class CAOCheck
    {
        public static bool CheckLeeftijdsregels(Medewerker medewerker)
        {

        }
    }
}